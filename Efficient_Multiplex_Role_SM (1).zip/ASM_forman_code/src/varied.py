import argparse
import numpy as np
import time

import tensorflow as tf

from sklearn.metrics import roc_auc_score
from sklearn.decomposition import PCA
import numpy as np
import random
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedShuffleSplit, StratifiedKFold
from sklearn.metrics import f1_score
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
import pandas as pd
from sklearn import svm
import matplotlib.pyplot as plt
import networkx as nx
from sklearn.manifold import TSNE
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import GridSearchCV
import matplotlib.pyplot as plt
import networkx as nx 
import numpy as np
import pandas as pd
import pickle
import random
import seaborn as sb
import sklearn as sk
from sklearn.cluster import KMeans
from sklearn.manifold import TSNE
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedShuffleSplit, StratifiedKFold
from sklearn.cluster import AgglomerativeClustering
from sklearn.metrics import f1_score
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
import sys
from sklearn.neighbors import KNeighborsClassifier
from shapes.shapes import *
from sklearn.metrics import pairwise_distances
from shapes.build_graph import *
from math import sqrt
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
import json

import argparse
import os
import time
import warnings

import models
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from sklearn.exceptions import UndefinedMetricWarning
from torch.utils.data import DataLoader
from models.utils import *
from sklearn.metrics.cluster import rand_score
from sklearn.metrics.cluster import adjusted_rand_score
warnings.filterwarnings(action='ignore', category=UndefinedMetricWarning)
warnings.filterwarnings(action='ignore', category=UserWarning)


def parse_args():
    parser = argparse.ArgumentParser(
        "Deep Recursive Network Embedding with Regular Equivalence")
    parser.add_argument('--dataset', type=str, default="barbell",
                        help='Directory to load data.')
    parser.add_argument('-s', '--struct', type=str, default="-1,128,64",
                        help='the network struct')
    parser.add_argument('-ls', '--layer_struct', type=str, default="-1,128,64",
                        help='the network layer_struct')
    parser.add_argument('-ln', '--node_struct', type=str, default="-1,128,64",
                        help='the network att_struct')   
    parser.add_argument('-e', '--epoch', type=int, default=500,
                        help='Number of epoch to train. Each epoch processes the training '
                             'data once completely')
    parser.add_argument('-b', '--batch_size', type=int, default=32,
                        help='Number of training examples processed per step')
    parser.add_argument('-lr', '--learning-rate', type=float, default=0.001,
                        help='initial learning rate')
    parser.add_argument("--b1", type=float, default=0.5,
                        help="adam: decay of first order momentum of gradient")
    parser.add_argument("--b2", type=float, default=0.999,
                        help="adam: decay of first order momentum of gradient")
    parser.add_argument("--num_hist", type=int, default=20,
                        help="num_hist")
    parser.add_argument('-a', '--alpha', type=float, default=1,
                        help='the rate of vae loss')
    parser.add_argument('--beta', type=float, default=1,
                        help='the rate of gan-node loss')
    parser.add_argument('-g', '--gamma', type=float, default=0.3,
                        help='the rate of gan-relation loss')
    parser.add_argument('--sampling', type=int, default=50, help='sample number')
    parser.add_argument('--num_workers', type=int, default=4, help='num of workers')
    parser.add_argument('--seed', type=int, default=1, help='random seed')
    parser.add_argument('--split_ratio', type=float, default=0.7, help='ratio to split the '
                                                                       'train data')
    parser.add_argument('--loop', type=int, default=100, help='num of classification')
    parser.add_argument('--model', type=str, default="Test2", help='name of model')
    parser.add_argument('--weight_decay', type=float, default=0.01, help='L2')
    parser.add_argument('--ricci', type=float, default=0.5, help='Ricci')
    parser.add_argument('--device', type=int, default=0, help='GPU')
    parser.add_argument('--no-classification', dest='classification', action='store_false',
                        help='classification')
    return parser.parse_args()



def test(labels,embedding):

    labels=np.array(labels)
    sss = StratifiedKFold(n_splits=5, shuffle=True, random_state=0)
#########################
    i = 1
    f1_micros = []
    f1_macros = []
    for split_train, split_test in sss.split(embedding, labels):

        model=KNeighborsClassifier(n_neighbors=4)
        model.fit(embedding[split_train], labels[split_train])        
        predictions = model.predict(embedding[split_test])
        f1_micro = f1_score(labels[split_test], predictions, average="micro")
        f1_macro = f1_score(labels[split_test], predictions, average="macro")
        f1_micros.append(f1_micro)
        f1_macros.append(f1_macro)
        i += 1
     #   print(f1_macros)
    return np.mean(f1_micros), np.mean(f1_macros)
def main(args):
    args.embsize=128
    args.save_path="wuliao"
    width_basis = 18
    np.random.seed(0)
    basis_type = "cycle_9" 
    nb_shapes = 18
    list_shapes = [["fan1",6],["star1",6],["house1"],["fan2",6],["star2",6],["house2"],["fan3",6],["star3",6],["house3"]]*2
    sample = open('varied.out', 'w') 
    Total_times=10
    ami=[]
    sil=[]
    hom=[]
    comp=[]
    rand=[]
    adj_rand=[]
    random.seed(0)
    np.random.seed(0)
    device = torch.device("cuda:5" if torch.cuda.is_available() else "cpu")
    args.device = device
    args.struct = list(map(lambda x: int(x), args.struct.split(',')))
    args.layer_struct = list(map(lambda x: int(x), args.layer_struct.split(',')))
    args.node_struct = list(map(lambda x: int(x), args.node_struct.split(',')))
    for times in range(Total_times):
        G, communities, plugins, role_id = build_structure(width_basis, basis_type, list_shapes, start=0,
                            rdm_basis_plugins =False, add_random_edges=0,
                            plot=False, savefig=False)
        graph=G
        #G=nx.relabel_nodes(G, lambda x: str(x))
        #print(list(G.nodes()))
        print( 'nb of nodes in the graph: ', G.number_of_nodes())
        print( 'nb of edges in the graph: ', G.number_of_edges())
        

        features = test_feature(graph, alpha=0.5, method="OTD", verbose="INFO",num_hist=args.num_hist)
        layer_features=layer_feature(graph,num_of_weights=3,diameter=10)
        node_features=node_feature(graph,diameter=10)
        model = getattr(models, args.model)(args, G, features,layer_features,node_features).to(device,
                                                              dtype=torch.float32)


        optimizer = torch.optim.Adam([
            {'params': model.ae.parameters(), 'weight_decay': 0},
            {'params': model.mlp.parameters(), },
        ], lr=args.learning_rate, weight_decay=args.weight_decay)


        t1 = time.time()
        total_time = 0
        for epoch in range(args.epoch):
            train_dataloader = DataLoader(list(G.nodes), args.batch_size, shuffle=True,
                                          num_workers=args.num_workers)
            total_loss = 0.0
            start = time.time()
            for idx, data in enumerate(train_dataloader):
                nodes = data
                optimizer.zero_grad()
                loss = model(nodes)
                loss.backward()
                optimizer.step()

                # print("Generator loss: {}, Discriminator loss: {}".format(
                #     loss_g.item(), loss_d.item()))
                total_loss += loss
            end = time.time()
            total_time += end - start
            print('epoch: {}, Total loss: {}, Time: {}'.format(
                epoch, total_loss.item(), end - start))
            '''
            if args.classification:
                embedding = model.get_embedding()
                embedding = embedding.data.cpu().numpy()
                np.save("{}{}".format(save_path, epoch), embedding)
                if (epoch + 1) % 10 == 0:
                    eval_dict = classification(embedding, lbl_path,split_ratio=args.split_ratio, loop=args.loop)
             '''
        t2 = time.time()
        print("Embedding training time: {}".format(total_time))
        print("Embedding all running time:{}".format(t2-t1))
        timepath = '../runningtime.txt'
        f = open(timepath, "a+")
        f.write("The {} running time :{}\n".format(args.dataset, t2 - t1))
        f.close()
        embeddings = model.get_embedding()
        embeddings = embeddings.data.cpu().numpy()



        
        trans_data=np.array([(embeddings[i]) for i in range(len(role_id))])
        colors = role_id
        nb_clust = len(np.unique(colors))
        km = sk.cluster.AgglomerativeClustering(n_clusters=nb_clust,linkage='complete')
        km.fit(trans_data)
        labels_pred = km.labels_

        labels = colors
        #a,b=test(colors,trans_data)
        rand.append(rand_score(colors, labels_pred))
        adj_rand.append(adjusted_rand_score(colors, labels_pred))
        ami.append(sk.metrics.adjusted_mutual_info_score(colors, labels_pred))
        sil.append(sk.metrics.silhouette_score(trans_data,labels_pred))  
        hom.append(sk.metrics.homogeneity_score(colors, labels_pred))
        comp.append(sk.metrics.completeness_score(colors, labels_pred))
    print ('Homogeneity \t Completeness \t AMI \t nb clusters \t Silhouette \t rand \t adj_rand \n', file = sample)
    print (str(np.mean(hom))+'\t'+str(np.mean(comp))+'\t'+str(np.mean(ami))+'\t'+str(np.mean(nb_clust))+'\t'+str(np.mean(sil))+'\t'+str(np.mean(rand))+'\t'+str(np.mean(adj_rand)), file = sample)
    print (str(np.std(hom))+'\t'+str(np.std(comp))+'\t'+str(np.std(ami))+'\t'+str(np.std(nb_clust))+'\t'+str(np.std(sil))+'\t'+str(np.std(rand))+'\t'+str(np.std(adj_rand)), file = sample)
    
    
    print("Homogeneity:  ",hom, file = sample)
    print("Completeness:  ",comp, file = sample)
    print("AMI:  ",ami, file = sample)
    print("Silhouette:  ",sil, file = sample)
if __name__ == '__main__':
    main(parse_args())
