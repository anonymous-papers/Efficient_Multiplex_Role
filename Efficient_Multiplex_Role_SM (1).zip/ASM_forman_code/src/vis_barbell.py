import argparse
import numpy as np
import time
import seaborn as sns
import tensorflow as tf
import matplotlib.pyplot as plt
from sklearn.metrics import roc_auc_score
from sklearn.decomposition import PCA
import numpy as np
import random
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedShuffleSplit, StratifiedKFold
from sklearn.metrics import f1_score
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
import pandas as pd
from sklearn import svm
import matplotlib
import networkx as nx
from sklearn.manifold import TSNE
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import GridSearchCV
import argparse
import numpy as np
import time
import tensorflow as tf
from sklearn.metrics import roc_auc_score
from sklearn.decomposition import PCA
import numpy as np
import random
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedShuffleSplit, StratifiedKFold
from sklearn.metrics import f1_score
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
import pandas as pd
from sklearn import svm
import matplotlib.pyplot as plt
import networkx as nx
from sklearn.manifold import TSNE
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import GridSearchCV
import matplotlib.pyplot as plt
import networkx as nx 
import numpy as np
from scipy.spatial.distance import euclidean
import pandas as pd
import pickle
import random
import seaborn as sb
import sklearn as sk
from sklearn.cluster import KMeans
from sklearn.manifold import TSNE
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedShuffleSplit, StratifiedKFold
from sklearn.cluster import AgglomerativeClustering
from sklearn.metrics import f1_score
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
import sys
from sklearn.neighbors import KNeighborsClassifier
from shapes.shapes import *
from sklearn.metrics import pairwise_distances
from shapes.build_graph import *
from math import sqrt
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
import json
from models.utils import *
import argparse
import os
import time
import warnings

import models
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from sklearn.exceptions import UndefinedMetricWarning
from torch.utils.data import DataLoader
def plot(embeddings):
    X=[]
    Y=[]
    Label=[]
    for i in range(0,37):
        X.append(embeddings[i][0])
        Y.append(embeddings[i][1])
    canvas_height = 15
    canvas_width = 15
    dot_size = 4500
    text_size = 18
    legend_setting = False #“brief” / “full” / False


    sns.set(style="whitegrid")

    # set canvas height & width
    plt.figure(figsize=(canvas_width, canvas_height))


    color_paltette=[(153,51,255),(0,176,240),(102,255,204),(204,255,153),(255,0,0),(255,255,0),(255,192,0),(204,0,204),(153,204,255),(255,204,204)]
    pts_colors=list(range(37))
    for i in range(37):
        if(i==0):
            pts_colors[i]="color_0"
        if(i==1 or i==2 or i==3 or i==4 or i==6 or i==7 or i==8 or i==9):
            pts_colors[i]="color_1"
        if(i==5 or i==10):
            pts_colors[i]="color_2"
        if(i==11 or i==12):
            pts_colors[i]="color_3"
            
            
        if(i==13 or i==14 or i==15 or i==16 or i==18 or i==19 or i==20 or i==21):
            pts_colors[i]="color_4"
        if(i==17 or i==22):
            pts_colors[i]="color_5"
        if(i==23 or i==24):
            pts_colors[i]="color_6"

        
        
        if(i==25 or i==26 or i==27 or i==28 or i==30 or i==31 or i==32 or i==33):
            pts_colors[i]="color_7"
        if(i==29 or i==34):
            pts_colors[i]="color_8"
        if(i==35 or i==36):
            pts_colors[i]="color_9"
        
        
        
    for i in range(10):
        color_paltette[i] = (color_paltette[i][0] / 255, color_paltette[i][1] / 255, color_paltette[i][2] / 255)
        
        
    # reorganize dataset
    draw_dataset1 = {'x': X[:25],
                    'y': Y[:25], 
                    'label':list(range(1, 25 + 1)),
                    'ptsize': dot_size,
                    "cpaltette": color_paltette[:7],
                    'colors':pts_colors[:25]}
                    
                    
    draw_dataset2 = {'x': X[25:37],
                    'y': Y[25:37], 
                    'label':list(range(26, 37 + 1)),
                    'ptsize': dot_size,
                    "cpaltette": color_paltette[7:10],
                    'colors':pts_colors[25:37]}
                    
    #draw scatterplot points
    ax = sns.scatterplot(x = "x",y = "y", alpha = 1,s = draw_dataset1["ptsize"],hue="colors", palette=draw_dataset1["cpaltette"], legend = legend_setting, data = draw_dataset1)
    ax = sns.scatterplot(x = "x",y = "y", alpha = 1,s = draw_dataset2["ptsize"],hue="colors", palette=draw_dataset2["cpaltette"], legend = legend_setting, data = draw_dataset2, marker='s')

    return ax
def caldis(embeddings):
    ans=0.0
    for i in range(37):
        for j in range(37):
            if (i in {1,2,3,4,6,7,8,9} and j in {1,2,3,4,6,7,8,9}):
                ans+=euclidean(embeddings[i],embeddings[j])
            if(i in {5,10} and j in {5,10}):
                ans+=euclidean(embeddings[i],embeddings[j])
            if(i in {11,12} and j in {11,12}):
                ans+=euclidean(embeddings[i],embeddings[j])
                
                
            if (i in {13,14,15,16,18,19,20,21} and j in {13,14,15,16,18,19,20,21}):
                ans+=euclidean(embeddings[i],embeddings[j])
            if (i in {17} and j in {22}):
                ans+=euclidean(embeddings[i],embeddings[j])
            if (i in {23} and j in {24}):
                ans+=euclidean(embeddings[i],embeddings[j])
                
                
                
                
            if (i in {25,26,27,28,30,31,32,33} and j in {25,26,27,28,30,31,32,33}):
                ans+=euclidean(embeddings[i],embeddings[j])
                
            if (i in {29} and j in {34}):
                ans+=euclidean(embeddings[i],embeddings[j])
                
            if (i in {35} and j in {36}):
                ans+=euclidean(embeddings[i],embeddings[j])
    return ans/2        
def parse_args():
    parser = argparse.ArgumentParser(
        "Deep Recursive Network Embedding with Regular Equivalence")
    parser.add_argument('--dataset', type=str, default="barbell",
                        help='Directory to load data.')
    parser.add_argument('-s', '--struct', type=str, default="-1,128,64",
                        help='the network struct')
    parser.add_argument('-ls', '--layer_struct', type=str, default="-1,128,64",
                        help='the network layer_struct')
    parser.add_argument('-ln', '--node_struct', type=str, default="-1,128,64",
                        help='the network att_struct')                        
    parser.add_argument('-e', '--epoch', type=int, default=1000,
                        help='Number of epoch to train. Each epoch processes the training '
                             'data once completely')
    parser.add_argument('-b', '--batch_size', type=int, default=128,
                        help='Number of training examples processed per step')
    parser.add_argument('-lr', '--learning-rate', type=float, default=0.001,
                        help='initial learning rate')
    parser.add_argument("--b1", type=float, default=0.5,
                        help="adam: decay of first order momentum of gradient")
    parser.add_argument("--b2", type=float, default=0.999,
                        help="adam: decay of first order momentum of gradient")
    parser.add_argument("--num_hist", type=int, default=20,
                        help="num_hist")
    parser.add_argument('-a', '--alpha', type=float, default=0.5,
                        help='the rate of ae loss')
    parser.add_argument('--beta', type=float, default=0.5,
                        help='the rate of layer loss')
    parser.add_argument('--embsize', type=float, default=128,
                        help='the embedding size')
    parser.add_argument('-g', '--gamma', type=float, default=0.3,
                        help='the rate of gan-relation loss')
    parser.add_argument('--sampling', type=int, default=50, help='sample number')
    parser.add_argument('--num_workers', type=int, default=4, help='num of workers')
    parser.add_argument('--seed', type=int, default=1, help='random seed')
    parser.add_argument('--split_ratio', type=float, default=0.7, help='ratio to split the '
                                                                       'train data')
    parser.add_argument('--loop', type=int, default=100, help='num of classification')
    parser.add_argument('--model', type=str, default="Test2", help='name of model')
    parser.add_argument('--weight_decay', type=float, default=0.01, help='L2')
    parser.add_argument('--ricci', type=float, default=0.5, help='Ricci')
    parser.add_argument('--device', type=int, default=0, help='GPU')
    parser.add_argument('--no-classification', dest='classification', action='store_false',
                        help='classification')
    return parser.parse_args()

def main(args):
    np.random.seed(int(time.time()) if args.seed == -1 else args.seed)
    args.save_path="wuliao"
    device = torch.device("cuda:5" if torch.cuda.is_available() else "cpu")
    args.device = device
    args.struct = list(map(lambda x: int(x), args.struct.split(',')))
    args.layer_struct = list(map(lambda x: int(x), args.layer_struct.split(',')))
    args.node_struct = list(map(lambda x: int(x), args.node_struct.split(',')))
    graph = nx.read_weighted_edgelist("dataset/barbell.edge", delimiter=" ", nodetype=int,create_using=nx.Graph())
    with open('dataset/barbell.att', 'r') as f:
        for line in f:
            # Split the line into node id and vector values
            node_id, *vector_values = line.split()
            # Convert the vector values to floats
            vector = np.array(list(map(float, vector_values)))
            # Add the node to the graph with its vector as an attribute
            if int(node_id) in graph:
                graph.nodes[int(node_id)]['vector'] = vector

    args.embsize=2
    features = test_feature(graph, alpha=0.5, method="OTD", verbose="INFO",num_hist=args.num_hist)
    layer_features=layer_feature(graph,num_of_weights=2,diameter=5)
    node_features=node_feature(graph,diameter=5)
    print(layer_features)
    model = getattr(models, args.model)(args, graph, features,layer_features,node_features).to(device,
                                                              dtype=torch.float32)


    optimizer = torch.optim.Adam([
        {'params': model.ae.parameters(), 'weight_decay': 0},
        {'params': model.mlp.parameters(), },
    ], lr=args.learning_rate, weight_decay=args.weight_decay)
    for epoch in range(args.epoch):
        print(epoch)
        train_dataloader = DataLoader(list(graph.nodes), args.batch_size, shuffle=True,
                                              num_workers=args.num_workers)
        total_loss = 0.0
        start = time.time()
        for idx, data in enumerate(train_dataloader):
            nodes = data
            optimizer.zero_grad()
            loss = model(nodes)
            loss.backward()
            optimizer.step()
            total_loss += loss
        print("loss:  ",total_loss)
  
    embeddings = model.get_embedding()
    embeddings = embeddings.data.cpu().numpy()
    print(embeddings)
    print(caldis(embeddings))
    ax=plot(embeddings)
    ax.axis("equal")
    ax.figure.savefig("barbell.pdf",bbox_inches='tight')
if __name__ == '__main__':
    main(parse_args())
