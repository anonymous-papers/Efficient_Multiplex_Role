import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


class Autoencoder(nn.Module):
    def __init__(self, G, config):
        super(Autoencoder, self).__init__()
        print(config)
        self.N = G.number_of_nodes()
        self.config = config
        self.encoder_h1 = nn.ModuleList(
            [nn.Linear(self.config.struct[i], self.config.struct[i + 1]) for i in
             range(len(self.config.struct) - 1)]).to(self.config.device, dtype=torch.float32)
        self.encoder_h2 = nn.ModuleList(
            [nn.Linear(self.config.layer_struct[i], self.config.layer_struct[i + 1]) for i in
             range(len(self.config.layer_struct) - 1)]).to(self.config.device, dtype=torch.float32)
        self.encoder_h3 = nn.ModuleList(
            [nn.Linear(self.config.node_struct[i], self.config.node_struct[i + 1]) for i in
             range(len(self.config.node_struct) - 1)]).to(self.config.device, dtype=torch.float32)
        #self.embedding=nn.Linear(64,2)
        self.embedding=nn.Linear(64*3,self.config.embsize)
        self.decoder_h1 = nn.ModuleList(
            [nn.Linear(self.config.embsize,128), nn.Linear(128,64), nn.Linear(64,self.config.struct[0] )]).to(self.config.device, dtype=torch.float32)
        self.decoder_h2 = nn.ModuleList(
            [nn.Linear(self.config.embsize,128), nn.Linear(128,64), nn.Linear(64,self.config.layer_struct[0] )]).to(self.config.device, dtype=torch.float32)
        self.decoder_h3 = nn.ModuleList(
            [nn.Linear(self.config.embsize,128), nn.Linear(128,64), nn.Linear(64,self.config.node_struct[0] )]).to(self.config.device, dtype=torch.float32)
        self.relu = nn.LeakyReLU(0.01, inplace=True)
        self.init_model_weight()

    def init_model_weight(self):
        for i in range(len(self.config.struct) - 1):
            nn.init.xavier_uniform_(self.encoder_h1[i].weight)
            nn.init.uniform_(self.encoder_h1[i].bias)
        for i in range(len(self.config.layer_struct) - 1):
            nn.init.xavier_uniform_(self.encoder_h2[i].weight)
            nn.init.uniform_(self.encoder_h2[i].bias)
        for i in range(len(self.config.node_struct) - 1):
            nn.init.xavier_uniform_(self.encoder_h3[i].weight)
            nn.init.uniform_(self.encoder_h3[i].bias)    
            
        for i in range(3 ):
            nn.init.xavier_uniform_(self.decoder_h1[i].weight)
            nn.init.uniform_(self.decoder_h1[i].bias)
        for i in range(3 ):
            nn.init.xavier_uniform_(self.decoder_h2[i].weight)
            nn.init.uniform_(self.decoder_h2[i].bias)
        for i in range(3 ):
            nn.init.xavier_uniform_(self.decoder_h3[i].weight)
            nn.init.uniform_(self.decoder_h3[i].bias)    
            
            
        nn.init.xavier_uniform_(self.embedding.weight)
        nn.init.uniform_(self.embedding.bias)    
        
    def encoder_network(self, h1_state,h2_state,h3_state):
    
        for i in range(len(self.config.struct) - 1):
            h1_state = F.tanh(self.encoder_h1[i](h1_state))
            
        for i in range(len(self.config.layer_struct) - 1):
            h2_state = F.tanh(self.encoder_h2[i](h2_state)) 
            
        for i in range(len(self.config.node_struct) - 1):
            h3_state = F.tanh(self.encoder_h3[i](h3_state)) 

        
        encoded = torch.cat((h1_state, h2_state,h3_state), dim=1)
        #encoded = h1_state
        encoded = F.tanh(self.embedding(encoded))
        
        
        return encoded

    def decoder_network(self, embedding):
        h1_state=embedding.clone()
        h2_state=embedding.clone()
        h3_state=embedding.clone()
        for i, layer in enumerate(self.decoder_h1):
            h1_state = layer(h1_state)
            if i != len(self.decoder_h1) - 1:
                h1_state = F.tanh(h1_state)
        for i, layer in enumerate(self.decoder_h2):
            h2_state = layer(h2_state)
            if i != len(self.decoder_h2) - 1:
                h2_state = F.tanh(h2_state)
        for i, layer in enumerate(self.decoder_h3):
            h3_state = layer(h3_state)
            if i != len(self.decoder_h3) - 1:
                h3_state = F.tanh(h3_state)        
                
                
        return h1_state, h2_state, h3_state

    def forward(self, h1_state,h2_state,h3_state):
        encoded = self.encoder_network(h1_state,h2_state,h3_state)
        h1_state, h2_state, h3_state = self.decoder_network(encoded)
        return encoded, h1_state, h2_state, h3_state

    def get_embedding(self, h1_state, h2_state, h3_state):
        encoded = self.encoder_network(h1_state,h2_state, h3_state)
        return encoded