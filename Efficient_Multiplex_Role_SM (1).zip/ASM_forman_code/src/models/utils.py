import logging
import random
import time
from collections import defaultdict
import networkx as nx
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from sklearn import metrics
from sklearn.linear_model import LogisticRegression
from sklearn.multiclass import OneVsRestClassifier
from sklearn.preprocessing import LabelBinarizer
from sklearn.utils import shuffle

from GraphRicciCurvature.FormanRicci import FormanRicci




def sampling_neighbors(G, node, samples=50):
    nodeset = [node]
    neighbors = list(G[node])
    if samples >= len(neighbors):
        nodeset.extend(neighbors)
    else:
        nodeset.extend(random.sample(neighbors, samples))
    result = list(set(nodeset))
    result.sort(key=nodeset.index)
    return result


def second_similarity(G):
    n = G.number_of_nodes()
    s = np.zeros((n, n))
    neighbor = [0] * n
    for node in G.nodes:
        neighbor[node] = list(G[node])
    for i in range(n):
        for j in range(i + 1, n):
            inter = [k for k in neighbor[i] if k in neighbor[j]]
            outer = list(set(neighbor[i] + neighbor[j]))
            s[i, j] = float(len(inter)) / len(outer)
            s[j, i] = float(len(inter)) / len(outer)
    return s


def load_data(graph_path):
    graph = pd.read_csv(graph_path, header=None, sep=' ')
    G = nx.from_edgelist(graph.values.tolist())
    G.remove_edges_from(nx.selfloop_edges(G))
    # feature = pd.read_csv(feature_path, sep=',').values
    return G


def get_degree_list(G):
    return np.array(sorted(dict(G.degree).items(), key=lambda x: x[0]))[:, 1]


def random_walk_embedding(G, iteration=1000, walk_length=3):
    for e in G.edges():
        G[e[0]][e[1]]['weight'] = 1.0

    N = len(G.nodes())
    E = len(G.edges())
    walker = RootedWalker(G, 1, 1)
    start = time.time()
    walker.preprocess_transition_probs()
    sentences = walker.simulate_walks(iteration, walk_length)
    finish = time.time()
    print(finish - start)
    print(N, E)
    pro_all = {}
    for s in sentences:
        ne = len(s) - 1
        if s[0] not in pro_all.keys():
            pro_all[s[0]] = {}
        for i in range(ne):
            if s[i] < s[i + 1]:
                e = (s[i], s[i + 1])
            else:
                e = (s[i + 1], s[i])
            if e not in pro_all[s[0]].keys():
                pro_all[s[0]][e] = 1
            else:
                pro_all[s[0]][e] += 1

    maxlen = 0
    minlen = 1e8
    prob = []
    for i in range(N):
        if len(pro_all[i].values()) > maxlen:
            maxlen = len(pro_all[i].values())
        if len(pro_all[i].values()) < minlen:
            minlen = len(pro_all[i].values())
        pro = list(pro_all[i].values())
        pro.sort(reverse=True)
        prob.append(pro)
    ee = [p + [0] * (maxlen - len(p)) for p in prob]
    print(maxlen, minlen)
    embed = np.array(ee) / maxlen
    print(embed.shape)
    return embed


def sample_equal_number_edges_non_edges(adj_mat, small_samples):
    edges = np.transpose(adj_mat.nonzero())
    num_edges = edges.shape[0]
    inverse_adj_mat = 1 - adj_mat
    non_edges = np.transpose(inverse_adj_mat.nonzero())
    num_non_edges = non_edges.shape[0]
    edges_sampled = edges[np.random.randint(num_edges, size=small_samples)]
    non_edges_sampled = non_edges[np.random.randint(num_non_edges, size=small_samples)]

    return edges_sampled, non_edges_sampled


def normalize_features_row(features):
    rowsum = np.array(features.sum(axis=1))
    d_inv_sqrt = np.power(rowsum, -1).flatten()
    d_inv_sqrt[np.isinf(d_inv_sqrt)] = 0.
    d_mat_inv_sqrt = np.diag(d_inv_sqrt)
    features = d_mat_inv_sqrt.dot(features)
    return features


def normalize_features_col(features):
    colsum = np.array(features.sum(axis=0))
    print(colsum.shape)
    features /= colsum
    print(features.sum(axis=0))
    return features


def test_feature(G, alpha=0.8, method="OTD", verbose="INFO", num_hist=20):
    frc = FormanRicci(G)
  
    frc.compute_ricci_curvature()
    G_frc = frc.G.copy()
    ricci_curvtures = list(nx.get_edge_attributes(G_frc, "formanCurvature").values())
    min_cur = min(ricci_curvtures)
    max_cur = max(ricci_curvtures)
    N = G.number_of_nodes()
    num_hist = 20
    embed = np.zeros((N, num_hist))
    for n in G_frc.nodes():
        n_ric = [G_frc[n][nb]['formanCurvature'] for nb in G_frc.neighbors(n)]
        embed[n] = np.histogram(n_ric, bins=num_hist, range=(min_cur, max_cur))[0]

    return embed

def layer_feature2(G, num_of_weights,diameter):

    N = G.number_of_nodes()
    embed = np.zeros((N, num_of_weights))
    decay=0.5
    
    for node in G.nodes():

        p=1
        neighbors = nx.single_source_shortest_path_length(G, node, cutoff=diameter)
        neighbor_edges = G.subgraph(neighbors).edges(data='weight')
 
        for k in range(diameter):
            for weight in range(num_of_weights):
                embed[node][weight]+= p* sum(1 for edge in neighbor_edges if ( (neighbors[edge[0]] == k  or neighbors[edge[1]] == k)and edge[2]==weight+1)   )
            p*=decay
    return embed
    
    
def layer_feature1(G, num_of_weights,diameter):

    N = G.number_of_nodes()
    embed = np.zeros((N, num_of_weights*diameter))
    decay=0.5
    tot=0
    for node in G.nodes():
 
        tot+=1
        if(tot%1000==0):
            print(tot)
        neighbors = nx.single_source_shortest_path_length(G, node, cutoff=diameter)
        neighbor_edges = G.subgraph(neighbors).edges(data='weight')
        
        for k in range(diameter):
            for weight in range(num_of_weights):
                embed[node][weight+ k*num_of_weights]=  sum(1 for edge in neighbor_edges if ( (neighbors[edge[0]] == k  or neighbors[edge[1]] == k)and edge[2]==weight+1)   )
            p*=decay
  
    return embed   
    
def count_edges_between_sets(G, set1, set2):
    edge_weights = defaultdict(int)
    for u in set1:
        for v in G.neighbors(u):
            if v in set2:
                weight = G[u][v].get('weight', 1) 
                edge_weights[weight] += 1
    return edge_weights
    
def layer_feature(G, num_of_weights,diameter):

    N = G.number_of_nodes()
    embed = np.zeros((N, num_of_weights*diameter))

    tot=0
    for node in G.nodes():
 
        tot+=1
        if(tot%1000==0):
            print(tot)

        for k in range(diameter):
            nodes_within_k = set(nx.single_source_shortest_path_length(G, node, cutoff=k).keys())

            nodes_within_k_plus_1 = set(nx.single_source_shortest_path_length(G, node, cutoff=k+1).keys())
            
            edge=count_edges_between_sets(G, nodes_within_k, nodes_within_k_plus_1-nodes_within_k)
            
            for weight in range(num_of_weights):
                embed[node][weight+ k*num_of_weights]= edge[weight]
  
    return embed   

    
def node_feature(G, diameter):

    N = G.number_of_nodes()
    embed = np.zeros((N, len(G.nodes[0]['vector'])))
    decay=0.5
    
    for node in G.nodes():
        p=1
        for k in range(diameter+1):
            nodes_within_k = set(nx.single_source_shortest_path_length(G, node, cutoff=k).keys())

            nodes_within_k_minus_1 = set(nx.single_source_shortest_path_length(G, node, cutoff=k-1).keys())

            for i in nodes_within_k - nodes_within_k_minus_1:
                embed[node] += G.nodes[i]['vector']*p
            p*=decay
    return embed
    
    
    
    
def compute_ricci(G, alpha=0.8, method="OTD", verbose="INFO"):
    orc = OllivierRicci(G, alpha=alpha, method=method, verbose=verbose)
    orc.compute_ricci_curvature()
    G_orc = orc.G.copy()
    node_ricci = nx.get_node_attributes(G_orc, "ricciCurvature")
    embed = np.zeros(G.number_of_nodes())
    for n in node_ricci.keys():
        embed[n] = node_ricci[n]
    temp = nx.get_edge_attributes(G_orc, 'ricciCurvature')
    N = G.number_of_nodes()
    edge_ricci = np.zeros((N, N))
    for key in temp.keys():
        edge_ricci[key] = temp[key]
    print(min(embed), max(embed))
    return embed, edge_ricci


