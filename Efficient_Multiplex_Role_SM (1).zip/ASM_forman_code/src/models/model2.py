import networkx as nx
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from .AE import Autoencoder
from .utils import *


class Test2(nn.Module):
    def __init__(self, config, graph, features,layer_features,node_features):
        super(Test2, self).__init__()
        self.config = config
        self.G = graph


        self.features = torch.from_numpy(features).to(self.config.device, dtype=torch.float32)
        self.layer_features = torch.from_numpy(layer_features).to(self.config.device, dtype=torch.float32)
        self.node_features = torch.from_numpy(node_features).to(self.config.device, dtype=torch.float32)
        self.config.struct[0] = self.features.shape[1]
        self.config.layer_struct[0] = self.layer_features.shape[1]
        self.config.node_struct[0] = self.node_features.shape[1]
        self.degree = torch.from_numpy(get_degree_list(self.G)).to(self.config.device,
                                                                   dtype=torch.float32).reshape(
            -1, 1)
        self.degree = torch.log(self.degree + 1)

        self.ae = Autoencoder(self.G, self.config).to(self.config.device, dtype=torch.float32)

        self.mlp = nn.ModuleList([
            nn.Linear(self.config.embsize,128),
            nn.Linear(128, 1)
        ]).to(self.config.device, dtype=torch.float32)
        for i in range(len(self.mlp)):
            nn.init.xavier_uniform_(self.mlp[i].weight)
            nn.init.uniform_(self.mlp[i].bias)
        self.mseLoss = nn.MSELoss()
        self.bceLoss = nn.BCEWithLogitsLoss()


    def mlp_out(self, embedding):
        for i, layer in enumerate(self.mlp):
            embedding = torch.relu(layer(embedding))
        return embedding



    def forward(self, input_):
        features = self.features[input_]
        layer_features = self.layer_features[input_]
        node_features = self.node_features[input_]
        embedding, ae_out_1, ae_out_2, ae_out_3  = self.ae(features,layer_features,node_features)



        structural_loss = self.config.alpha * F.mse_loss(ae_out_1, features)
        layer_loss= self.config.beta * F.mse_loss(ae_out_2, layer_features)
        att_loss= self.config.beta * F.mse_loss(ae_out_3, node_features)
        guide_loss = self.config.gamma * F.l1_loss(self.mlp_out(embedding),
                                                   self.degree[input_])

        
        return structural_loss  + layer_loss + att_loss+ guide_loss 

    def get_embedding(self):
        return self.ae.get_embedding(self.features,self.layer_features,self.node_features)
